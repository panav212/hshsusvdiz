package com.brokesmpv1.economy;

import com.brokesmpv1.BrokeSMPV1;
import org.bukkit.entity.Player;
import java.util.*;

public class EconomyManager {
    private final BrokeSMPV1 plugin;
    private final Map<UUID, Integer> coins = new HashMap<>();
    private final Map<UUID, Integer> essence = new HashMap<>();

    public EconomyManager(BrokeSMPV1 plugin){ this.plugin = plugin; }

    public int getCoins(Player p){ return coins.getOrDefault(p.getUniqueId(), 0); }
    public void setCoins(Player p, int amt){ coins.put(p.getUniqueId(), Math.max(0, amt)); }
    public void addCoins(Player p, int delta){ setCoins(p, getCoins(p)+delta); }
    public boolean takeCoins(Player p, int delta){
        int bal = getCoins(p);
        if (bal < delta) return false;
        setCoins(p, bal - delta);
        return true;
    }

    public int getEssence(Player p){ return essence.getOrDefault(p.getUniqueId(), 0); }
    public void addEssence(Player p, int delta){ essence.put(p.getUniqueId(), Math.max(0, getEssence(p)+delta)); }
    public boolean spendEssence(Player p, int cost){
        int have = getEssence(p);
        if (have < cost) return false;
        essence.put(p.getUniqueId(), have - cost);
        return true;
    }
}
