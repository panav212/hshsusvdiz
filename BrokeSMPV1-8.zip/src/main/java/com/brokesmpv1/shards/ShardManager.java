package com.brokesmpv1.shards;

import com.brokesmpv1.BrokeSMPV1;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import java.util.*;

public class ShardManager {
    private final BrokeSMPV1 plugin;
    private final Map<UUID, ShardType> equipped = new HashMap<>();
    private final Map<UUID, Integer> tiers = new HashMap<>();
    private final Map<UUID, Integer> killUnlock = new HashMap<>();
    private final Set<UUID> extraUnlocked = new HashSet<>();

    public ShardManager(BrokeSMPV1 plugin){ this.plugin = plugin; }

    public void giveShard(Player p, ShardType type, int tier){
        equipped.put(p.getUniqueId(), type);
        tiers.put(p.getUniqueId(), Math.max(1, Math.min(3, tier)));
        p.getInventory().addItem(type.getItem(tier));
        p.sendMessage("§aEquipped shard: §e" + type.getDisplayName() + " §7(Tier " + tier + ")");
    }

    public ShardType getEquipped(Player p){ return equipped.get(p.getUniqueId()); }
    public int getTier(Player p){ return tiers.getOrDefault(p.getUniqueId(), 1); }
    public int getKillProgress(Player p){ return killUnlock.getOrDefault(p.getUniqueId(), 0); }
    public boolean hasExtra(Player p){ return extraUnlocked.contains(p.getUniqueId()); }

    public void addKillProgress(Player p){
        int v = Math.min(5, getKillProgress(p)+1);
        killUnlock.put(p.getUniqueId(), v);
        if (v == 5) p.sendMessage("§dKill ability unlocked for this life!");
    }

    public void resetKillProgress(Player p){ killUnlock.remove(p.getUniqueId()); }

    public void unlockExtra(Player p){
        extraUnlocked.add(p.getUniqueId());
    }
}
