package com.brokesmpv1.shards;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

public abstract class ShardAbility {
    public enum Trigger { PASSIVE, HIT, KILL, EXTRA }

    private final Trigger trigger;
    public ShardAbility(Trigger trigger){ this.trigger = trigger; }
    public Trigger getTrigger(){ return trigger; }

    public void onPassive(Player owner) {}
    public void onHit(Player owner, Entity victim) {}
    public void onKill(Player owner, Entity victim) {}
    public void onExtra(Player owner, Entity context) {}
}
