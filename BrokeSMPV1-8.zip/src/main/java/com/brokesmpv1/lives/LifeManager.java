package com.brokesmpv1.lives;

import com.brokesmpv1.BrokeSMPV1;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import java.util.*;

public class LifeManager implements Listener {
    private final BrokeSMPV1 plugin;
    private final Map<UUID, Integer> lives = new HashMap<>();

    public LifeManager(BrokeSMPV1 plugin){ this.plugin = plugin; }

    public int getLives(Player p){ return lives.getOrDefault(p.getUniqueId(), 3); }
    public void setLives(Player p, int v){ lives.put(p.getUniqueId(), Math.max(0, v)); }
    public void addLives(Player p, int v){ setLives(p, getLives(p)+v); }
    public void removeLives(Player p, int v){ setLives(p, getLives(p)-v); }

    @EventHandler
    public void onDeath(PlayerDeathEvent e){
        Player p = e.getEntity();
        removeLives(p, 1);
        p.sendMessage("§cYou lost a life. Lives left: §e" + getLives(p));
        if (getLives(p) <= 0){
            p.setGameMode(GameMode.SPECTATOR);
            p.sendMessage("§4No lives left. You are now in Spectator mode.");
        }
    }
}
