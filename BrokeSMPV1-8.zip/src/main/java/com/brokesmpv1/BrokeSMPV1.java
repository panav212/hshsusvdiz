package com.brokesmpv1;

import com.brokesmpv1.commands.*;
import com.brokesmpv1.npc.NpcManager;
import com.brokesmpv1.shards.AbilityListener;
import com.brokesmpv1.shards.ShardManager;
import com.brokesmpv1.tasks.TaskManager;
import com.brokesmpv1.economy.EconomyManager;
import com.brokesmpv1.lives.LifeManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class BrokeSMPV1 extends JavaPlugin {

    private static BrokeSMPV1 instance;
    private EconomyManager economy;
    private ShardManager shards;
    private TaskManager tasks;
    private NpcManager npcs;
    private LifeManager lives;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.economy = new EconomyManager(this);
        this.shards = new ShardManager(this);
        this.tasks  = new TaskManager(this);
        this.npcs   = new NpcManager(this);
        this.lives  = new LifeManager(this);

        Bukkit.getPluginManager().registerEvents(new AbilityListener(this), this);
        Bukkit.getPluginManager().registerEvents(npcs, this);
        Bukkit.getPluginManager().registerEvents(tasks, this);

        getCommand("settasknpc").setExecutor(new SetTaskNpcCommand(this));
        getCommand("setshopnpc").setExecutor(new SetShopNpcCommand(this));
        getCommand("recipe").setExecutor(new RecipeCommand());
        getCommand("balance").setExecutor(new BalanceCommand(this));
        getCommand("coins").setExecutor(new CoinsCommand(this));
        getCommand("life").setExecutor(new LifeCommand(this));
        getCommand("shard").setExecutor(new ShardCommand(this));
        getCommand("essence").setExecutor(new EssenceCommand(this));

        getLogger().info("BrokeSMPV1 enabled.");
    }

    public static BrokeSMPV1 get() { return instance; }
    public EconomyManager economy(){ return economy; }
    public ShardManager shards(){ return shards; }
    public TaskManager tasks(){ return tasks; }
    public NpcManager npcs(){ return npcs; }
    public LifeManager lives(){ return lives; }
}
