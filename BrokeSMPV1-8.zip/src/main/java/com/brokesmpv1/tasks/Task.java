package com.brokesmpv1.tasks;

import org.bukkit.*;
import org.bukkit.advancement.*;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

public class Task {
    private final String title;
    private final String goalDesc;
    private final int reward;
    private int progress;
    private int goal;
    private boolean completed;
    private boolean claimed;

    private final Type type;
    private final EntityType killType;
    private final Material mineType;
    private final String advancementKey;

    public enum Type { KILL, MINE, FISH, TRAVEL, ADVANCEMENT }

    private Task(Type type, String title, String goalDesc, int reward, EntityType killType, Material mineType, String advancementKey, int goal){
        this.type = type;
        this.title = title;
        this.goalDesc = goalDesc;
        this.reward = reward;
        this.killType = killType;
        this.mineType = mineType;
        this.advancementKey = advancementKey;
        this.goal = goal;
    }

    public static Task kill(String title, String desc, EntityType type, int goal, int reward){
        return new Task(Type.KILL, title, desc, reward, type, null, null, goal);
    }
    public static Task mine(String title, String desc, Material mat, int goal, int reward){
        return new Task(Type.MINE, title, desc, reward, null, mat, null, goal);
    }
    public static Task fish(String title, String desc, int goal, int reward){
        return new Task(Type.FISH, title, desc, reward, null, null, null, goal);
    }
    public static Task travel(String title, String desc, int blocks, int reward){
        return new Task(Type.TRAVEL, title, desc, reward, null, null, null, blocks);
    }
    public static Task adv(String title, String advKey, int reward){
        return new Task(Type.ADVANCEMENT, title, "Complete advancement", reward, null, null, advKey, 1);
    }

    public String title(){ return title; }
    public String goalDesc(){ return goalDesc; }
    public int reward(){ return reward; }
    public boolean completed(){ return completed; }
    public boolean claimed(){ return claimed; }
    public void setClaimed(boolean v){ this.claimed = v; }

    public void onKill(Player p, EntityType killed){
        if (type != Type.KILL || killType != killed) return;
        progress++; check();
    }
    public void onMine(Player p, Material mat){
        if (type != Type.MINE || mineType != mat) return;
        progress++; check();
    }
    public void onFish(Player p){
        if (type != Type.FISH) return;
        progress++; check();
    }
    public void onTravel(Player p, int blocks){
        if (type != Type.TRAVEL) return;
        progress += Math.max(0, blocks); check();
    }
    public void onAdvancement(Player p){
        if (type != Type.ADVANCEMENT) return;
        Advancement adv = Bukkit.getAdvancement(NamespacedKey.fromString(advancementKey));
        if (adv == null) return;
        AdvancementProgress prog = p.getAdvancementProgress(adv);
        if (prog.isDone()) {
            progress = 1; completed = true;
        }
    }

    private void check(){ if (progress >= goal) completed = true; }
}
